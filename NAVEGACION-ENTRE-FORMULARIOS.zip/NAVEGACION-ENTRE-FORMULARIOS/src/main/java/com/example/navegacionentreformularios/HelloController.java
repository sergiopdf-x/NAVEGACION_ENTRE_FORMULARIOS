package com.example.navegacionentreformularios;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HelloController {
    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField txtContra;
    @FXML
    private ComboBox<String> cmbRol;
    @FXML
    private Label lblMensaje;

    @FXML
    public void initialize(){
        cmbRol.getItems().addAll(
                "Administrador",
                "Cajero"
        );
    }

    @FXML
    public void btnIngresar(){
        String usuario = txtUsuario.getText().trim();
        String contra = txtContra.getText().trim();
        String rol = cmbRol.getValue();

        if (usuario.isEmpty() || contra.isEmpty() || rol == null){
            lblMensaje.setText("Se debe completar todos los campos");
            return;
        }

        try{
            if (usuario.equals("admin") && contra.equals("1234")
                && rol.equals("Administrador")){
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Administrador.fxml"));
                Stage stage = new Stage();
                stage.setScene(new Scene(loader.load()));
                stage.setTitle("Administrador");
                stage.show();

                Stage login = (Stage) txtUsuario.getScene().getWindow();
                login.close();
            }else if(usuario.equals("cajero") && contra.equals("123")
                    && rol.equals("Cajero")){
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Cajero.fxml"));
                Stage stage = new Stage();
                stage.setScene(new Scene(loader.load()));
                stage.setTitle("Cajero");
                stage.show();

                Stage login = (Stage) txtUsuario.getScene().getWindow();
                login.close();
            }else{
                lblMensaje.setText("Usuario o contraseña incorreccto");
            }
        }catch(Exception e){
                lblMensaje.setText("Error al abrir la ventana ");
                e.printStackTrace();
        }
    }

    @FXML
    public void btnSalir(){
        System.exit(0);
    }
}