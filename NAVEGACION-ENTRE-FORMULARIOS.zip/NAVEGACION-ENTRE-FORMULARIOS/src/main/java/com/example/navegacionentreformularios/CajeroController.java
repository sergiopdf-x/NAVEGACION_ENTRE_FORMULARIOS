package com.example.navegacionentreformularios;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class CajeroController {
    @FXML
    private Button btnCerrarSesion;
    @FXML
    public void btnCerrarSesion(){
        Stage stage = (Stage) btnCerrarSesion.getScene().getWindow();
        stage.close();
    }
}
