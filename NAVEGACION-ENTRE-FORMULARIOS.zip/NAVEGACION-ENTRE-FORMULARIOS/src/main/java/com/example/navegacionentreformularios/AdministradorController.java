package com.example.navegacionentreformularios;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class AdministradorController {
    @FXML
    private Button btnCerrar;
    @FXML
    public void btnCerrar(){
        Stage stage = (Stage) btnCerrar.getScene().getWindow();
        stage.close();
    }
}
