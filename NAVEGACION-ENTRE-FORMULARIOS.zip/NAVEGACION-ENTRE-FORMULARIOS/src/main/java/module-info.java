module com.example.navegacionentreformularios {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.navegacionentreformularios to javafx.fxml;
    exports com.example.navegacionentreformularios;
}