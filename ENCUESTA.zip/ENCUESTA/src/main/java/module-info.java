module com.example.encuesta {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.encuesta to javafx.fxml;
    exports com.example.encuesta;
}