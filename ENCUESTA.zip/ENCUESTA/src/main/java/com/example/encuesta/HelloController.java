package com.example.encuesta;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;

public class HelloController {
    @FXML
    private RadioButton rb1965;
    @FXML
    private RadioButton rb1969;
    @FXML
    private RadioButton rb1972;
    @FXML
    private RadioButton rbAtlantico;
    @FXML
    private RadioButton rbIndico;
    @FXML
    private RadioButton rbPacifico;
    @FXML
    private RadioButton rbGarciaMarquez;
    @FXML
    private RadioButton rbCervantes;
    @FXML
    private RadioButton rbNeruda;
    @FXML
    private RadioButton rbPlata;
    @FXML
    private RadioButton rbOro;
    @FXML
    private RadioButton rbAluminio;
    @FXML
    private Label lblMensaje;

    @FXML
    public void btnCalificar(){
        int correctas = 0;
        if (rb1969.isSelected()){
            correctas ++;
        }
        if (rbPacifico.isSelected()){
            correctas ++;
        }
        if (rbCervantes.isSelected()){
            correctas ++;
        }
        if (rbOro.isSelected()){
            correctas ++;
        }

        int incorrectas = 4 - correctas;
        int puntaje = correctas * 5;

        lblMensaje.setText(
                "Correctas: " + correctas + "\nIncorrectas: " + incorrectas
                + "\nPuntaje obtenido: " + puntaje + "/20"
        );
    }
}
